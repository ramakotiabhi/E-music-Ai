# music/views.py
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
import spotipy
from spotipy.oauth2 import SpotifyClientCredentials, SpotifyOAuth
from django.conf import settings
import random

# Spotify Authentication Settings
SPOTIFY_REDIRECT_URI = 'http://127.0.0.1:8000/music/spotify-callback/'
SCOPE = 'user-library-read playlist-modify-public user-top-reads user-read-recently-played'

@login_required
def music_home(request):
    return render(request, 'music/home.html', {
        'title': 'Music Home'
    })

@login_required
def spotify_login(request):
    sp_oauth = SpotifyOAuth(
        client_id=settings.SPOTIFY_CLIENT_ID,
        client_secret=settings.SPOTIFY_CLIENT_SECRET,
        redirect_uri=SPOTIFY_REDIRECT_URI,
        scope=SCOPE
    )
    auth_url = sp_oauth.get_authorize_url()
    return redirect(auth_url)

@login_required
def spotify_callback(request):
    sp_oauth = SpotifyOAuth(
        client_id=settings.SPOTIFY_CLIENT_ID,
        client_secret=settings.SPOTIFY_CLIENT_SECRET,
        redirect_uri=SPOTIFY_REDIRECT_URI,
        scope=SCOPE
    )
    code = request.GET.get('code')
    token_info = sp_oauth.get_access_token(code)
    request.session['token_info'] = token_info
    return redirect('music:recommendations')

# Predefined genres and recommendations
# Predefined genres and recommendations
FALLBACK_GENRES = [
    'pop', 'rock', 'hip-hop', 'jazz', 'classical', 'electronic', 
    'r&b', 'indie', 'country', 'latin', 'k-pop', 'metal'
]

FALLBACK_RECOMMENDATIONS = [
    {
        'name': 'Shape of You',
        'artist': 'Ed Sheeran',
        'album': '÷ (Divide)',
        'image_url': 'https://i.scdn.co/image/ab67616d0000b273ba5db46f4b838ef6027e6f96',
        'preview_url': None,
        'spotify_url': 'https://open.spotify.com/track/7qiZfU4dY1lWllzX7mPBI3'
    },
    {
        'name': 'Blinding Lights',
        'artist': 'The Weeknd',
        'album': 'After Hours',
        'image_url': 'https://i.scdn.co/image/ab67616d0000b2738863bc11d2aa12b54f5aeb36',
        'preview_url': None,
        'spotify_url': 'https://open.spotify.com/track/0VjIjW4GlUZAMYd2vXMi3b'
    },
    {
        'name': 'Butter',
        'artist': 'BTS',
        'album': 'Butter',
        'image_url': 'https://i.scdn.co/image/ab67616d0000b273d9197c7122d8a9f1c5772a5b',
        'preview_url': None,
        'spotify_url': 'https://open.spotify.com/track/2bgTY4UwhfBYhGT4HUYStN'
    },
    {
        'name': 'Stay',
        'artist': 'The Kid LAROI & Justin Bieber',
        'album': 'F*CK LOVE 3: OVER YOU',
        'image_url': 'https://i.scdn.co/image/ab67616d0000b273ca99f5fb2ffd45206fb59acf',
        'preview_url': None,
        'spotify_url': 'https://open.spotify.com/track/5PjdY0CKGZdEuoNab3yDmX'
    },
    {
        'name': 'good 4 u',
        'artist': 'Olivia Rodrigo',
        'album': 'SOUR',
        'image_url': 'https://i.scdn.co/image/ab67616d0000b273a91c10fe9472d9bd89802e5a',
        'preview_url': None,
        'spotify_url': 'https://open.spotify.com/track/4ZtFanR9U6ndgddUvNcjcG'
    },
    {
        'name': 'Bad Guy',
        'artist': 'Billie Eilish',
        'album': 'WHEN WE ALL FALL ASLEEP, WHERE DO WE GO?',
        'image_url': 'https://i.scdn.co/image/ab67616d0000b27350a3147b4edd7701a876c6ce',
        'preview_url': None,
        'spotify_url': 'https://open.spotify.com/track/2Fxmhks0bxGSBdJ92vM42m'
    },
    {
        'name': 'Uptown Funk',
        'artist': 'Mark Ronson ft. Bruno Mars',
        'album': 'Uptown Special',
        'image_url': 'https://i.scdn.co/image/ab67616d0000b273e419ccba0baa8bd3f3d7abf2',
        'preview_url': None,
        'spotify_url': 'https://open.spotify.com/track/32OlwWuMpZ6b0aN2RZOeMS'
    },
    {
        'name': 'Bohemian Rhapsody',
        'artist': 'Queen',
        'album': 'A Night at the Opera',
        'image_url': 'https://i.scdn.co/image/ab67616d0000b273d254ca497999ae980a5a38c5',
        'preview_url': None,
        'spotify_url': 'https://open.spotify.com/track/3z8h0TU7ReDPLIbEnYhWZb'
    },
    {
        'name': 'Dynamite',
        'artist': 'BTS',
        'album': 'Dynamite (DayTime Version)',
        'image_url': 'https://i.scdn.co/image/ab67616d0000b273a8ae7a851f8977b76ea4c0c7',
        'preview_url': None,
        'spotify_url': 'https://open.spotify.com/track/4saklk6nie3yiGePpBwUoc'
    },
    {
        'name': 'Levitating',
        'artist': 'Dua Lipa ft. DaBaby',
        'album': 'Future Nostalgia',
        'image_url': 'https://i.scdn.co/image/ab67616d0000b273bd26ede1ae69327010d49946',
        'preview_url': None,
        'spotify_url': 'https://open.spotify.com/track/39LLxExYz6ewLAcYrzQQyP'
    },
    {
        'name': 'Watermelon Sugar',
        'artist': 'Harry Styles',
        'album': 'Fine Line',
        'image_url': 'https://i.scdn.co/image/ab67616d0000b273d4daf28d55fe4197ede848be',
        'preview_url': None,
        'spotify_url': 'https://open.spotify.com/track/6UelLqGlWMcVH1E5c4H7lY'
    },
    {
        'name': 'Save Your Tears',
        'artist': 'The Weeknd & Ariana Grande',
        'album': 'Save Your Tears (Remix)',
        'image_url': 'https://i.scdn.co/image/ab67616d0000b273c6af5ffa661a365b77df6ef6',
        'preview_url': None,
        'spotify_url': 'https://open.spotify.com/track/37BZB0z9T8Xu7U3e65qxFy'
    }
]

@login_required
def music_recommendations(request):
    try:
        token_info = request.session.get('token_info')
        if token_info:
            sp = spotipy.Spotify(auth=token_info['access_token'])
        else:
            auth_manager = SpotifyClientCredentials(
                client_id=settings.SPOTIFY_CLIENT_ID,
                client_secret=settings.SPOTIFY_CLIENT_SECRET
            )
            sp = spotipy.Spotify(auth_manager=auth_manager)

        # Get trending tracks
        playlists = sp.category_playlists(category_id='toplists', limit=5)
        
        recommendations = []
        for playlist in playlists['playlists']['items']:
            try:
                tracks = sp.playlist_tracks(playlist['id'], limit=3)
                for item in tracks['items']:
                    if item['track']:
                        track = item['track']
                        recommendations.append({
                            'name': track['name'],
                            'artist': track['artists'][0]['name'],
                            'album': track['album']['name'],
                            'image_url': track['album']['images'][0]['url'] if track['album']['images'] else None,
                            'preview_url': track['preview_url'],
                            'spotify_url': track['external_urls']['spotify']
                        })
            except:
                continue

        if not recommendations:
            recommendations = FALLBACK_RECOMMENDATIONS

        selected_genres = random.sample(FALLBACK_GENRES, 3)

        context = {
            'recommendations': recommendations[:15],
            'selected_genres': selected_genres,
            'is_spotify_connected': bool(token_info)
        }

        return render(request, 'music/recommendations.html', context)

    except Exception as e:
        context = {
            'recommendations': FALLBACK_RECOMMENDATIONS,
            'selected_genres': random.sample(FALLBACK_GENRES, 3),
            'is_spotify_connected': False
        }
        return render(request, 'music/recommendations.html', context)