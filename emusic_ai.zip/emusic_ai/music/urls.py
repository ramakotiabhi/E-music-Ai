# music/urls.py
from django.urls import path
from . import views

app_name = 'music'

urlpatterns = [
    path('', views.music_home, name='music_home'),
    path('recommendations/', views.music_recommendations, name='recommendations'),
    path('spotify-login/', views.spotify_login, name='spotify_login'),
    path('spotify-callback/', views.spotify_callback, name='spotify_callback'),
    path('recommendations/', views.music_recommendations, name='recommendations'),
]    