# subscriptions/views.py
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone

@login_required
def subscription_plans(request):
    return render(request, 'subscriptions/plans.html')

@login_required
def checkout(request, plan_type):
    # Simple plan selection without payment processing
    plan_details = {
        'basic': {'name': 'Basic Plan', 'price': '0'},
        'premium': {'name': 'Premium Plan', 'price': '9.99'},
        'family': {'name': 'Family Plan', 'price': '14.99'}
    }
    
    selected_plan = plan_details.get(plan_type)
    if not selected_plan:
        messages.error(request, 'Invalid plan selected.')
        return redirect('subscriptions:plans')
        
    return render(request, 'subscriptions/checkout.html', {
        'plan': selected_plan
    })