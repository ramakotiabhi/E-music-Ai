# chatbot/views.py
from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json

def chatbot(request):
    return render(request, 'chatbot/chat.html')

@csrf_exempt
def send_message(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            user_message = data.get('message', '')

            # Simple response logic without OpenAI
            responses = {
                'hello': 'Hi! How can I help you with music today?',
                'hi': 'Hello! Ask me anything about music!',
                'music': 'Music is a beautiful form of art! What would you like to know?',
                'song': 'There are many amazing songs! What genre are you interested in?',
                'genre': 'I can tell you about various genres like Pop, Rock, Jazz, Classical, and more!',
                'artist': 'There are many talented artists! Who would you like to know about?',
                'recommend': 'I can recommend music based on your preferences! What do you usually listen to?',
                'help': 'I can help you with music recommendations, artist information, genres, and more!'
            }

            # Default response if no keyword matches
            response = "I'm your music assistant! Feel free to ask about songs, artists, genres, or recommendations!"

            # Check for keywords in user message
            user_message_lower = user_message.lower()
            for key in responses:
                if key in user_message_lower:
                    response = responses[key]
                    break

            return JsonResponse({
                'status': 'success',
                'response': response
            })

        except Exception as e:
            print(f"Error: {str(e)}")
            return JsonResponse({
                'status': 'error',
                'message': 'An error occurred while processing your request.'
            })

    return JsonResponse({
        'status': 'error',
        'message': 'Invalid request method'
    })