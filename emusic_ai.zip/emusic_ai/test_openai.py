# test_openai.py
import openai

openai.api_key = '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'  # Replace with your actual API key

try:
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "user", "content": "Hello"}
        ]
    )
    print("Test successful!")
    print("Response:", response.choices[0].message['content'])
except Exception as e:
    print("Error:", str(e))