# test_spotify.py
import spotipy
from spotipy.oauth2 import SpotifyClientCredentials
import os
from dotenv import load_dotenv

load_dotenv()

def test_spotify():
    try:
        auth_manager = SpotifyClientCredentials(
            client_id='e407c6f2f64641e4b99e362dde5a1b92',
            client_secret='f765ec471ae848f381dfbb44ab1b6ff0'
        )
        sp = spotipy.Spotify(auth_manager=auth_manager)
        
        # Test API call
        results = sp.search(q='test', limit=1)
        print("Spotify API test successful!")
        return True
    except Exception as e:
        print(f"Error: {str(e)}")
        return False

if __name__ == "__main__":
    test_spotify()